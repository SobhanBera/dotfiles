<?php
/* vim: set expandtab sw=4 ts=4 sts=4: */
/**
 * Theme information
 *
 *
 * @version $Id$
 * @package phpMyAdmin-theme
 * @subpackage Smooth_Yellow
 */

$theme_name = 'Smooth Yellow';
$theme_version = 3;
$theme_generation = 3;
?>
